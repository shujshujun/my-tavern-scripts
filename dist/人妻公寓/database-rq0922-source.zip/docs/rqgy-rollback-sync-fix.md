# RQGY 回档同步修复

基线为 spv9.2.3 源码提交 c99fa5c。本分支是本地配套修复，未发布官方版本。

## 原因与修复

MESSAGE_DELETED 在宿主删楼后触发；插件原先等待1.2秒才恢复被删检查点。其间任何插件保存都会以当前聊天覆盖检查点保管库，丢弃待恢复副本。RQGY 的流水清理在约500毫秒开始，能够触发这条竞态。

现在删楼调度入口同步保留保管库，恢复尚未成功时 post-save 不覆盖它。恢复成功且删除世代、聊天身份仍一致后再刷新副本。保存失败保留恢复材料供重试；普通未发生外部删楼的保存仍按原规则同步，插件主动 purge 的原测试继续通过。

公开 API 新增 `synchronizeChatTimeline({reason:'deleted'|'swiped'})`，返回 `Promise<{success:boolean}>`。它使用原回放调度器，但可立即刷新防抖队列并等待真实检查点恢复及 runtime reload 完成。并发请求共享串行回放，期间新事件继续收口；取消、切聊天、恢复或加载失败均不返回成功许可。游戏收到许可后仍需校验自己的冻结楼层和稳定快照。

## 验证与交付

- 检查点、调度、SQL API、回调、V2恢复及导入持久化六组回归：97项通过。
- TypeScript `tsc --noEmit` 通过。
- 本地 userscript 隔离构建位于 `.codex-tmp/build/database-rollback-local.js`，标记为 `9.2.3-rqgy-rollback-local`；正式 index.js、dist/index.bundle.js 与 manifest.json 哈希不变。
- 与游戏侧 `数据库桥.ts` 的同步确认配套使用。游戏代码位于 `D:/SillyTavern/tavern_helper_template-xmj-reply-fix`。

修复保护仍可恢复的检查点并消除这条覆盖竞态。已经从存档和备份中实际丢失的数据无法由代码重建；没有使用清空全部记忆或伪造回放完成的方式放行。尚未在玩家出错存档中做真实浏览器验收。
